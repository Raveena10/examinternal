import React, { useState  } from "react";
import './button.css';

function Index() {
    const [count, setCount] = useState(0);
    const [showmsg, setShowmsg] = useState("");
      const divideby =(count)=>{
        if(count%5==0 && count%3==0)
        {
            return "OOPS it's divided by 3 and 5 both"
        }
        if(count%3==0)
        {
            return "OOPS it's only divided by 3"
        }
        if(count%5==0)
        {
            return "OOPS it's only divided by 5"
        }
        
      }
      const incrementmethod =()=>{
        var increment= count + 1
        setCount(increment)
        setShowmsg(divideby(increment))
      }
      
      const decrementmethod =()=>{
        var decrement = count - 1
        setCount(decrement)
        setShowmsg(divideby(decrement))
      }

  return (
      <>
      <h1>{showmsg}</h1>
      <h3>Number : {count}</h3>
         <button
              type="submit"
              onClick={incrementmethod}
              class="button"
            >
              Increment
            </button>
          <button
            type="submit"
            onClick={decrementmethod}
            class="button"
          > Decrement</button>
      </>
  )
}

export default Index