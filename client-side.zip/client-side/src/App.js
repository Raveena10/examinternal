
import './App.css';
import UseStateButton from './Components/UseStateButton';
import { Route, Switch} from "react-router-dom";

function App() {
  return (
    <>
    <Switch>
      <Route path="/" exact component={UseStateButton}></Route>
    </Switch>
    </>
  );
}

export default App;
